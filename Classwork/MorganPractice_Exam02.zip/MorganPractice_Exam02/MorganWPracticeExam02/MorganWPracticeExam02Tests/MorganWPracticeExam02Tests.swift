//
//  MorganWPracticeExam02Tests.swift
//  MorganWPracticeExam02Tests
//
//  Created by Morgan,Wyatt J on 4/1/25.
//

import Testing
@testable import MorganWPracticeExam02

struct MorganWPracticeExam02Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
