//
//  Morgan_Exam02Tests.swift
//  Morgan_Exam02Tests
//
//  Created by Morgan,Wyatt J on 4/3/25.
//

import Testing
@testable import Morgan_Exam02

struct Morgan_Exam02Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
