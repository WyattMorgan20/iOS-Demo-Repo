//
//  Morgan_Exam03Tests.swift
//  Morgan_Exam03Tests
//
//  Created by Wyatt Morgan on 4/22/25.
//

import Testing
@testable import Morgan_Exam03

struct Morgan_Exam03Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
