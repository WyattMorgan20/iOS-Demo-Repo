//
//  Morgan_Exam01Tests.swift
//  Morgan_Exam01Tests
//
//  Created by Morgan,Wyatt J on 2/25/25.
//

import Testing
@testable import Morgan_Exam01

struct Morgan_Exam01Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
