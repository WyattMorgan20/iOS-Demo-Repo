//
//  ViewController.swift
//  Morgan_PracticeExam
//
//  Created by Wyatt Morgan on 2/20/25.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var heightFTOT: UITextField!
    
    @IBOutlet weak var heightINOT: UITextField!
    
    @IBOutlet weak var weightOT: UITextField!
    
    @IBOutlet weak var outputOT: UILabel!
    
    @IBOutlet weak var imageOT: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calcBTNClicked(_ sender: UIButton) {
        let heightFTIN = heightFTOT.text!
        let heightININ = heightINOT.text!
        
        let heightFT: Double? = Double(heightFTIN)
        let heightIN: Double? = Double(heightININ)
        
        var totalHeight: Double? = (heightFT! * 12) + heightIN!
        
        let weightIN = Double(weightOT.text!)
        
        var BMI: Double = round((703 * (weightIN! / (totalHeight! * totalHeight!))) * 10) / 10
        
        var category: String = ""
        var healthTip: String = ""
        
        if BMI <= 18.5{
            category = "Underweight"
            healthTip = "Eat more protein and healthy fats."
            imageOT.image = UIImage(named: "underWeight")
        }
        else if 18.5 < BMI && BMI <= 24.9 {
            category = "Normal"
            healthTip = "Excellent! Maintain a balanced lifestyle."
            imageOT.image = UIImage(named: "normal")
            
        }
        else if 24.9 < BMI && BMI <= 29.9 {
            category = "Overweight"
            healthTip = "Lose weight by maintaining a balanced diet less and increasing physical activity."
            imageOT.image = UIImage(named: "overWeight")
        }
        else{
            category = "Obesity/Obese"
            healthTip = "Consult a doctor for personalized advice."
            imageOT.image = UIImage(named: "obese")
        }
        
        outputOT.text =
        """
            Your Body Mass Index is \(BMI).
            This is considered \(category).
            Health tip: \(healthTip).
        """
        
        
    }
    
}

