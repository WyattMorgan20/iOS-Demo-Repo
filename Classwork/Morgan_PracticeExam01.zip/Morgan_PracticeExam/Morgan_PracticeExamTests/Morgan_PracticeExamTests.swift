//
//  Morgan_PracticeExamTests.swift
//  Morgan_PracticeExamTests
//
//  Created by Wyatt Morgan on 2/20/25.
//

import Testing
@testable import Morgan_PracticeExam

struct Morgan_PracticeExamTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
