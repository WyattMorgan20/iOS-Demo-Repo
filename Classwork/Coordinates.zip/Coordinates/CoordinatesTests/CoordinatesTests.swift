//
//  CoordinatesTests.swift
//  CoordinatesTests
//
//  Created by Morgan,Wyatt J on 3/4/25.
//

import Testing
@testable import Coordinates

struct CoordinatesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
