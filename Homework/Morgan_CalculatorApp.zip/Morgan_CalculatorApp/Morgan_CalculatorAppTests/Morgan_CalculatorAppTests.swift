//
//  Morgan_CalculatorAppTests.swift
//  Morgan_CalculatorAppTests
//
//  Created by Wyatt Morgan on 2/24/25.
//

import Testing
@testable import Morgan_CalculatorApp

struct Morgan_CalculatorAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
