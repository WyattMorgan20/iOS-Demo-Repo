//
//  ViewController.swift
//  Morgan_CalculatorApp
//
//  Created by Wyatt Morgan on 2/24/25.
//

import UIKit

class ViewController: UIViewController {

    var firstNum: String = ""
    var operation: String = ""
    var secondNum: String = ""
    var haveResult: Bool = false;
    var resultNum: String = ""
    var numAfterResult: String = ""
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // default value is 0
        resultOutlet.text = "0"
        // Do any additional setup after loading the view.
    }
    
    // function to change the display when operations are used
    func updateDisplay(_ value: String){
        print("Updating display: \(value)")
        resultOutlet.text = value
    }
    
    // function to add numbers to the end of the string until an operation is pressed
    func appendNum(_ num: String){
        print("Appending: \(num)")
        if haveResult{
            firstNum = num
            haveResult = false
        }
        else if operation.isEmpty {
            if num == "." && firstNum.contains("."){
                return
            }
            firstNum += num
        }
        else {
            if num == "." && secondNum.contains(".") {
                return
            }
            secondNum += num
        }
        
        updateDisplay(operation.isEmpty ? firstNum : secondNum)
    }

    @IBAction func ACBtnPressed(_ sender: UIButton) {
        // AC
        firstNum = ""
        operation = ""
        secondNum = ""
        haveResult = false
        updateDisplay("0")
    }
    
    @IBAction func CBtnPressed(_ sender: UIButton) {
        // C
        if !secondNum.isEmpty {
            secondNum.removeLast()
            updateDisplay(secondNum.isEmpty ? "0" : secondNum)
        }
        else if !operation.isEmpty {
            operation = ""
            updateDisplay(firstNum)
        }
        else if !firstNum.isEmpty {
            firstNum.removeLast()
            updateDisplay(firstNum.isEmpty ? "0" : firstNum)
        }
    }
    
    @IBAction func changeBtnPressed(_ sender: UIButton) {
        // -/+
        if !firstNum.isEmpty && operation.isEmpty {
            firstNum = String(-Double(firstNum)!)
            updateDisplay(firstNum)
        }
        else if !secondNum.isEmpty {
            secondNum = String(-Double(secondNum)!)
            updateDisplay(secondNum)
        }
    }
    
    @IBAction func divideBtnPressed(_ sender: UIButton) {
        // /
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func multiplyBtnPressed(_ sender: UIButton) {
        // *
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func subtractBtnPressed(_ sender: UIButton) {
        // -
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func addBtnPressed(_ sender: UIButton) {
        // +
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func decimalBtnPressed(_ sender: UIButton) {
        // .
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func percentBtnPressed(_ sender: UIButton) {
        // %
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func equalsBtnPressed(_ sender: UIButton) {
        // =
        // kept getting bugs if I didn't put "gaurd" in front here:
        guard let num1 = Double(firstNum), let num2 = Double(secondNum) else {
            return
        }
        
        var result: Double?
        
        switch operation {
            case "+": result = num1 + num2
            case "-": result = num1 - num2
            case "*": result = num1 * num2
            case "/": result = num2 != 0 ? num1 / num2 : nil
            case "%": result = num1.truncatingRemainder(dividingBy: num2)
            default: break
        }
        
        if let res = result {
            resultNum = res.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(res)) : String(res)
        }
        else{
            resultNum = "nan"
        }
        
        updateDisplay(resultNum)
        firstNum = resultNum
        secondNum = ""
        operation = ""
        haveResult = true
    }
    
    @IBAction func zeroBtnPressed(_ sender: UIButton) {
        // 0
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func oneBtnPressed(_ sender: UIButton) {
        // 1
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func twoBtnPressed(_ sender: UIButton) {
        // 2
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func threeBtnPressed(_ sender: UIButton) {
        // 3
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func fourBtnPressed(_ sender: UIButton) {
        // 4
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func fiveBtnPressed(_ sender: UIButton) {
        // 5
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func sixBtnPressed(_ sender: UIButton) {
        // 6
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func sevenBtnPressed(_ sender: UIButton) {
        // 7
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func eightBtnPressed(_ sender: UIButton) {
        // 8
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func nineBtnPressed(_ sender: UIButton) {
        // 9
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
}

