//
//  ViewController.swift
//  Morgan_CalculatorApp
//
//  Created by Wyatt Morgan on 2/24/25.
//

import UIKit

class ViewController: UIViewController {

    var firstNum: String = ""
    var operation: String = ""
    var secondNum: String = ""
    var haveResult: Bool = false;
    var resultNum: String = ""
    var numAfterResult: String = ""
    
    @IBOutlet weak var resultOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ACBtnPressed(_ sender: UIButton) {
        // AC
        
    }
    
    @IBAction func CBtnPressed(_ sender: UIButton) {
        // C
        
    }
    
    @IBAction func changeBtnPressed(_ sender: UIButton) {
        // -/+
        
    }
    
    @IBAction func divideBtnPressed(_ sender: UIButton) {
        // /
        
    }
    
    @IBAction func multiplyBtnPressed(_ sender: UIButton) {
        // *
        
    }
    
    @IBAction func subtractBtnPressed(_ sender: UIButton) {
        // -
        
    }
    
    @IBAction func addBtnPressed(_ sender: UIButton) {
        // +
        
    }
    
    @IBAction func decimalBtnPressed(_ sender: UIButton) {
        // .
        
    }
    
    @IBAction func percentBtnPressed(_ sender: UIButton) {
        // %
        
    }
    
    @IBAction func equalsBtnPressed(_ sender: UIButton) {
        // =
        
    }
    
    @IBAction func zeroBtnPressed(_ sender: UIButton) {
        // 0
        
    }
    
    @IBAction func oneBtnPressed(_ sender: UIButton) {
        // 1
        
    }
    
    @IBAction func twoBtnPressed(_ sender: UIButton) {
        // 2
        
    }
    
    @IBAction func threeBtnPressed(_ sender: UIButton) {
        // 3
        
    }
    
    @IBAction func fourBtnPressed(_ sender: UIButton) {
        // 4
        
    }
    
    @IBAction func fiveBtnPressed(_ sender: UIButton) {
        // 5
        
    }
    
    
    @IBAction func sixBtnPressed(_ sender: UIButton) {
        // 6
        
    }
    
    
    @IBAction func sevenBtnPressed(_ sender: UIButton) {
        // 7
        
    }
    
    
    @IBAction func eightBtnPressed(_ sender: UIButton) {
        // 8
        
    }
    
    
    @IBAction func nineBtnPressed(_ sender: UIButton) {
        // 9
        
    }
    
    
    
    
    
    
}

