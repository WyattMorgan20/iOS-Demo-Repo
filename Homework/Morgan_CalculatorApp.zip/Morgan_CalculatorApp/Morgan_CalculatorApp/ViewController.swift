//
//  ViewController.swift
//  Morgan_CalculatorApp
//
//  Created by Wyatt Morgan on 2/24/25.
//

import UIKit

class ViewController: UIViewController {

    var firstNum: String = ""
    var operation: String = ""
    var secondNum: String = ""
    var haveResult: Bool = false;
    var resultNum: String = ""
    var numAfterResult: String = ""
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    // variables for buttons due errors found without them:
    @IBOutlet weak var zeroBtn: UIButton!
    @IBOutlet weak var oneBtn: UIButton!
    @IBOutlet weak var twoBtn: UIButton!
    @IBOutlet weak var threeBtn: UIButton!
    @IBOutlet weak var fourBtn: UIButton!
    @IBOutlet weak var fiveBtn: UIButton!
    @IBOutlet weak var sixBtn: UIButton!
    @IBOutlet weak var sevenBtn: UIButton!
    @IBOutlet weak var eightBtn: UIButton!
    @IBOutlet weak var nineBtn: UIButton!
    @IBOutlet weak var decimalBtn: UIButton!
    @IBOutlet weak var percentBtn: UIButton!
    @IBOutlet weak var equalsBtn: UIButton!
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var subtractBtn: UIButton!
    @IBOutlet weak var multiplyBtn: UIButton!
    @IBOutlet weak var ACBtn: UIButton!
    @IBOutlet weak var divideBtn: UIButton!
    @IBOutlet weak var CBtn: UIButton!
    @IBOutlet weak var changeBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // default value is 0
        resultOutlet.text = "0"
        
        // had to hard code titles for all of the buttons...
        // I don't know why because I set the titles in the storyboard for each
        // but here we are I guess...
        oneBtn.setTitle("1", for: .normal)
        twoBtn.setTitle("2", for: .normal)
        threeBtn.setTitle("3", for: .normal)
        fourBtn.setTitle("4", for: .normal)
        fiveBtn.setTitle("5", for: .normal)
        sixBtn.setTitle("6", for: .normal)
        sevenBtn.setTitle("7", for: .normal)
        eightBtn.setTitle("8", for: .normal)
        nineBtn.setTitle("9", for: .normal)
        zeroBtn.setTitle("0", for: .normal)
        decimalBtn.setTitle(".", for: .normal)
        percentBtn.setTitle("%", for: .normal)
        equalsBtn.setTitle("=", for: .normal)
        addBtn.setTitle("+", for: .normal)
        subtractBtn.setTitle("-", for: .normal)
        multiplyBtn.setTitle("*", for: .normal)
        ACBtn.setTitle("AC", for: .normal)
        CBtn.setTitle("C", for: .normal)
        divideBtn.setTitle("/", for: .normal)
        changeBtn.setTitle("-/+", for: .normal)
        // Do any additional setup after loading the view.
    }
    
    // function to change the display when operations are used
    func updateDisplay(_ value: String){
        resultOutlet.text = value
    }
    
    // function to add numbers to the end of the string until an operation is pressed
    func appendNum(_ num: String){
        if haveResult{
            firstNum = num
            haveResult = false
        }
        else if operation.isEmpty {
            if num == "." && firstNum.contains("."){
                return
            }
            firstNum += num
        }
        else {
            if num == "." && secondNum.contains(".") {
                return
            }
            secondNum += num
        }
        updateDisplay(operation.isEmpty ? firstNum : secondNum)
    }

    // Operation and equals btn functions:
    @IBAction func ACBtnPressed(_ sender: UIButton) {
        // AC
        firstNum = ""
        operation = ""
        secondNum = ""
        haveResult = false
        updateDisplay("0")
    }
    
    @IBAction func CBtnPressed(_ sender: UIButton) {
        // C
        if !secondNum.isEmpty {
            secondNum.removeLast()
            updateDisplay(secondNum.isEmpty ? "0" : secondNum)
        }
        else if !operation.isEmpty {
            operation = ""
            updateDisplay(firstNum)
        }
        else if !firstNum.isEmpty {
            firstNum.removeLast()
            updateDisplay(firstNum.isEmpty ? "0" : firstNum)
        }
    }
    
    @IBAction func changeBtnPressed(_ sender: UIButton) {
        // -/+
        if !firstNum.isEmpty && operation.isEmpty {
            firstNum = String(-Double(firstNum)!)
            updateDisplay(firstNum)
        }
        else if !secondNum.isEmpty {
            secondNum = String(-Double(secondNum)!)
            updateDisplay(secondNum)
        }
    }
    
    @IBAction func divideBtnPressed(_ sender: UIButton) {
        // /
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func multiplyBtnPressed(_ sender: UIButton) {
        // *
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func subtractBtnPressed(_ sender: UIButton) {
        // -
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func addBtnPressed(_ sender: UIButton) {
        // +
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func decimalBtnPressed(_ sender: UIButton) {
        // .
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func percentBtnPressed(_ sender: UIButton) {
        // %
        if let op = sender.currentTitle, !firstNum.isEmpty {
            operation = op
            updateDisplay(op)
        }
    }
    
    @IBAction func equalsBtnPressed(_ sender: UIButton) {
        // =
        // kept getting bugs if I didn't put "gaurd" in front here:
        guard !firstNum.isEmpty, let num1 = Double(firstNum) else {
            return
        }
        
        var num2: Double = 0
        if !secondNum.isEmpty, let parsedNum2 = Double(secondNum) {
            num2 = parsedNum2
        }
        
        var result: Double?
        
        switch operation {
            case "+": result = num1 + num2
            case "-": result = num1 - num2
            case "*": result = num1 * num2
            case "/": result = num2 != 0 ? num1 / num2 : nil
            case "%": result = num1.truncatingRemainder(dividingBy: num2)
            default: result = num1
        }
        
        if let res = result {
            resultNum = res.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(res)) : String(res)
        }
        else{
            resultNum = "nan"
        }
        
        updateDisplay(resultNum)
        
        updateDisplay(resultNum)
        firstNum = resultNum
        secondNum = ""
        operation = ""
        haveResult = true
    }
    
    // number button functions:
    @IBAction func zeroBtnPressed(_ sender: UIButton) {
        // 0
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func oneBtnPressed(_ sender: UIButton) {
        // 1
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func twoBtnPressed(_ sender: UIButton) {
        // 2
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func threeBtnPressed(_ sender: UIButton) {
        // 3
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func fourBtnPressed(_ sender: UIButton) {
        // 4
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    @IBAction func fiveBtnPressed(_ sender: UIButton) {
        // 5
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func sixBtnPressed(_ sender: UIButton) {
        // 6
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func sevenBtnPressed(_ sender: UIButton) {
        // 7
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func eightBtnPressed(_ sender: UIButton) {
        // 8
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
    
    @IBAction func nineBtnPressed(_ sender: UIButton) {
        // 9
        if let numVal = sender.currentTitle {
            appendNum(numVal)
        }
    }
    
}

