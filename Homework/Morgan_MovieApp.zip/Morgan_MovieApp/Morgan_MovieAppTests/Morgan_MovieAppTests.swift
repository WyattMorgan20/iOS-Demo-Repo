//
//  Morgan_MovieAppTests.swift
//  Morgan_MovieAppTests
//
//  Created by Wyatt Morgan on 4/25/25.
//

import Testing
@testable import Morgan_MovieApp

struct Morgan_MovieAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
