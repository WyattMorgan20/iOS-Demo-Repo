//
//  ViewController.swift
//  Morgan_Assignment02
//
//  Created by Wyatt Morgan on 2/5/25.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        
        let name = nameOutlet.text!
        
        if let billAMT = Double(billAmountOutlet.text!),
           let tipIn = Double(tipPercentageOutlet.text!){
            
            nameLabel.text = "Name: \(name)"
            billAmountLabel.text = "Bill Amount: $\(billAMT)"
            
            let billNum = billAMT
                
            var tipPer = (billNum * tipIn) / 100
            tipAmountLabel.text = "Tip Amount: $\(tipPer)"
            
            var totalNum = billNum + tipPer
            totalAmountLabel.text = "Total Amount: $\(totalNum)"
        }
        else{
            tipAmountLabel.text = "Invalid Value Inputs..."
        }
        
    }
    
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""
    }
    
}

