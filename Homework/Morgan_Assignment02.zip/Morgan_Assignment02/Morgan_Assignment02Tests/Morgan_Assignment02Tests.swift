//
//  Morgan_Assignment02Tests.swift
//  Morgan_Assignment02Tests
//
//  Created by Wyatt Morgan on 2/5/25.
//

import Testing
@testable import Morgan_Assignment02

struct Morgan_Assignment02Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
