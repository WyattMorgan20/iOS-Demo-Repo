//
//  Morgan_SearchAppTests.swift
//  Morgan_SearchAppTests
//
//  Created by Wyatt Morgan on 3/31/25.
//

import Testing
@testable import Morgan_SearchApp

struct Morgan_SearchAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
