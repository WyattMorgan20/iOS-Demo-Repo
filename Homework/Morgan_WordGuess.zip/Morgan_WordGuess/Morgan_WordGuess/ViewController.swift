//
//  ViewController.swift
//  Morgan_WordGuess
//
//  Created by Wyatt Morgan on 3/5/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var guessBTN: UIButton!
    
    @IBOutlet weak var playAgainBTN: UIButton!
    
    var words = [
        ["Destiny", "Cursed Devs"],
        ["Basenji", "Dog"],
        ["Car", "Vehicle"],
        ["Northwest", "School"]
    ]
    
    var count = 0
    var word = ""
    var lettersGuessed = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // Guess button should be disabled at start
        guessBTN.isEnabled = false
        
        // Get first word from the array
        word = words[count][0]
        userGuessLabel.text = ""
        
        // Populate the display label with the underscores.
        // The # of underscores is equal to the # of characters in the word
        updateUnderscores();
        
        // Get the first hint from the array
        hintLabel.text = words[count][1]
        
        // Clear the status label initially
        statusLabel.text = ""
    }

    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        // Get the text from the text field
        var letter = guessLetterField.text!
        
        // Replace the guessed letter if the letter is part of the word
        lettersGuessed = lettersGuessed + letter
        var revealedWord = ""
        for item in word{
            if lettersGuessed.contains(item){
                revealedWord += "\(item)"
            }
            else{
                revealedWord += "_ "
            }
        }
        
        // Assigning the word to dispayOL after a guess
        userGuessLabel.text = revealedWord
        guessLetterField.text = ""
        
        // If the word is guessed cofrectly we are enabling the
        // Play again button
        if userGuessLabel.text!.contains("_") == false{
            playAgainBTN.isHidden = false
            guessBTN.isEnabled = false
        }
        guessBTN.isEnabled = false
    }
    
    @IBAction func playAgainbuttonPressed(_ sender: UIButton) {
        // Reset the button to disable initially
        playAgainBTN.isHidden = true
        
        // Clear the label
        lettersGuessed = ""
        count += 1
        
        // If count reaches the end of the array
        // (all the words are guessed sucessfully),
        // then print Congratulations in the status label
        if count == words.count{
            statusLabel.text = "Congratulations! You are done with the game!"
            
            // Clearing the labels
            userGuessLabel.text = ""
            hintLabel.text = ""
        }
        else{
            // Fetch the next word from the array
            word = words[count][0]
            
            // Fetch the hint related to the word
            hintLabel.text = words[count][1]
            
            // Enabling the check button
            guessBTN.isEnabled = true
            
            userGuessLabel.text = ""
            updateUnderscores()
        }
    }
    
    @IBAction func letterInput(_ sender: UITextField) {
        // Read the data from the text field
        var textEntered = guessLetterField.text!
        
        // Consider only the last character by calling
        // textEntered.last and trimming the white spaces
        textEntered = String(textEntered.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = textEntered
        
        // Check whether the entered text is empty or not to enable check button
        if textEntered.isEmpty{
            guessBTN.isEnabled = false
        }
        else{
            guessBTN.isEnabled = true
        }
    }
    
    func updateUnderscores(){
        for letter in word{
            userGuessLabel.text! += "_ "
        }
    }
    
}

