//
//  ViewController.swift
//  Morgan_WordGuess
//
//  Created by Wyatt Morgan on 3/5/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var guessBTN: UIButton!
    
    @IBOutlet weak var playAgainBTN: UIButton!
    
    var words: [(word: String, hint: String, imageName: String)] = [
        ("Destiny", "Cursed Devs", "destiny"),
        ("Basenji", "Dog", "basenji"),
        ("Car", "Vehicle", "car"),
        ("Northwest", "School", "nw"),
        ("Joji", "Career Switch", "joji")
    ]
    
    let maxNumOfWrongGuesses = 10
    var wrongGuessCount = 0
    var wordsGuessed = 0
    var count = 0
    var word = ""
    var lettersGuessed = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        wordsGuessedLabel.text = "Words Guessed: 0"
        wordsRemainingLabel.text = "Words Remaining: \(words.count)"
        totalWordsLabel.text = "Total Words: \(words.count)"
        guessCountLabel.text = "Guesses Remaining: \(maxNumOfWrongGuesses)"
        
        guessBTN.isEnabled = true

        word = words[count].word
        userGuessLabel.text = ""
        
        updateUnderscores()

        hintLabel.text = words[count].hint
        
        statusLabel.text = ""
    }


    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        guard let letter = guessLetterField.text, !letter.isEmpty else {
            return
        }
        
        lettersGuessed += letter
        var revealedWord = ""

        for item in word {
            if lettersGuessed.contains(item) {
                revealedWord += "\(item) "
            } else {
                revealedWord += "_ "
            }
        }
        
        userGuessLabel.text = revealedWord.trimmingCharacters(in: .whitespaces)
        guessLetterField.text = ""

        if word.contains(letter) {
            if userGuessLabel.text!.contains("_") {
                statusLabel.text = "Good guess! Keep going."
            } else {
                statusLabel.text = "You've guessed it correctly! '\(word)' 🎉"
                statusLabel.numberOfLines = 0
                
                // displaying the proper image
                displayImage.image = UIImage(named: words[count].imageName)
                
                playAgainBTN.isHidden = false
                guessBTN.isEnabled = false
                wordsGuessed += 1
                wordsGuessedLabel.text = "Words Guessed: \(wordsGuessed)"
                wordsRemainingLabel.text = "Words Remaining: \(words.count - wordsGuessed)"
            }
        } else {
            wrongGuessCount += 1
            guessCountLabel.text = "Guesses Remaining: \(maxNumOfWrongGuesses - wrongGuessCount)"
            statusLabel.text = "Wrong guess. Try again."
            statusLabel.numberOfLines = 0

            if wrongGuessCount == maxNumOfWrongGuesses {
                statusLabel.text = "You have used all the available guesses, Please play again."
                statusLabel.numberOfLines = 0
                playAgainBTN.isHidden = false
                guessBTN.isEnabled = false
            }
        }
    }
    
    @IBAction func playAgainbuttonPressed(_ sender: UIButton) {
        playAgainBTN.isHidden = true
        lettersGuessed = ""
        wrongGuessCount = 0
        guessCountLabel.text = "Guesses Remaining: \(maxNumOfWrongGuesses)"

        if wordsGuessed == words.count {
            statusLabel.text = "Congratulations! You are done, Please start over again."
            statusLabel.numberOfLines = 0
            wordsGuessed = 0
            wordsRemainingLabel.text = "Words Remaining: \(words.count)"
            wordsGuessedLabel.text = "Words Guessed: 0"
            count = 0
        } else {
            count += 1
        }

        word = words[count].word
        hintLabel.text = words[count].hint
        userGuessLabel.text = ""
        updateUnderscores()
        guessBTN.isEnabled = false
        statusLabel.text = ""
    }
    
    @IBAction func letterInput(_ sender: UITextField) {
        var textEntered = guessLetterField.text!
        
        textEntered = String(textEntered.last ?? " ").trimmingCharacters(in: .whitespaces)
        guessLetterField.text = textEntered
        
        if textEntered.isEmpty{
            guessBTN.isEnabled = false
        }
        else{
            guessBTN.isEnabled = true
        }
    }
    
    func updateUnderscores(){
        for letter in word{
            userGuessLabel.text! += "_ "
        }
    }

    
}

